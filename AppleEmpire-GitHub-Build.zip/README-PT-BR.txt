COOKIE EMPIRE — PROJETO ANDROID
================================

Este é um projeto Android Studio que empacota o jogo HTML em um aplicativo Android usando WebView.
O jogo não usa anúncios nem exige conexão com a internet. O progresso fica no armazenamento local do app.

COMO GERAR O APK
1. Extraia o ZIP para uma pasta no computador.
2. Instale o Android Studio (versão atual) e abra a pasta CookieEmpireAndroid.
3. Aguarde a sincronização do Gradle. Se solicitado, instale Android SDK Platform 35.
4. Para testar: conecte um celular Android com Depuração USB ativada e clique em Run.
5. Para gerar APK: menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O Android Studio mostrará o caminho do APK gerado, normalmente:
   app/build/outputs/apk/debug/app-debug.apk

OBSERVAÇÕES
- Este ZIP contém o projeto-fonte; o APK ainda precisa ser compilado no Android Studio.
- Não foi possível testar em aparelho físico nesta etapa.
- Para distribuir fora do teste, gere uma versão assinada em Build > Generate Signed App Bundle or APK.


BUILD AUTOMÁTICO PELO GITHUB
1. Crie um repositório no GitHub.
2. Extraia este ZIP e envie todos os arquivos para a raiz do repositório.
3. Confirme que existe o caminho .github/workflows/build-apk.yml.
4. Envie (Commit) os arquivos para a branch main ou master.
5. No GitHub, abra Actions e selecione "Build Cookie Empire APK".
6. Quando o fluxo terminar com sucesso, abra a execução e baixe o artefato "Cookie-Empire-APK".
7. Dentro do ZIP do artefato estará app-debug.apk.

Também é possível iniciar manualmente em Actions > Build Cookie Empire APK > Run workflow.
O APK gerado é de depuração, adequado para testes; para publicação, gere um APK/AAB assinado.
